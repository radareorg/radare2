# Sample RCore plugin in C

This directory contains a basic RCore plugin for radare2 written in C.

The plugin registers a new command 'hello' which prints 'world' and have access to all the APIs in r2.

Use this as a template and extend it for your needs.
